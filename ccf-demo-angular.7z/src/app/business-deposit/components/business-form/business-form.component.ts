/*--------------------------------------------------------------------------------------------------------
                NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group                  :        PES
Project/Product        :        Newgen - OAO
Application            :        Newgen Portal
Module                 :
File Name              :
Author                 :
Date (DD/MM/YYYY)      :
Description            :
-------------------------------------------------------------------------------------------------------
                CHANGE HISTORY
-------------------------------------------------------------------------------------------------------
Problem No/CR No     Change Date     Changed By        Change Description
--------------------------------------------------------------------------------------------------------*/

import { Component, OnInit, Input, EventEmitter, Output, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { IMyDpOptions, IMyInputFieldChanged } from 'mydatepicker';

import { AddressComponent } from '../../../shared/components/address/address.component';

import { MdmService } from '../../../core/apis/mdm.service';
import { UspsService } from '../../../core/apis/usps.service';
import { PageLoaderService } from '../../../core/components/page-loader/page-loader.service';
import { ApplicationError } from '../../../core/error-handler/error-handler.service';
import { DataService } from '../../../core/services/data.service';
import { FormUtilityService } from '../../../core/services/form-utility.service';
import { CustomValidation } from '../../../core/utility/custom-validations';
import { SharedMdmService } from '../../../shared/services/shared-mdm.service';

import { BusinessDetails } from '../../../core/models/application.model';
import { BusinessSubType, BusinessType, BusinessCategory, OwnershipStructure, BusinessPhoneType } from '../../../core/models/fields-value.model';
import { ZipDetails } from '../../../core/models/usps-response.model';


@Component({
	selector: 'business-form',
	templateUrl: './business-form.component.html',
	styleUrls: ['./business-form.component.scss'],
	providers: [
		MdmService
	]
})
export class BusinessFormComponent implements OnInit, AfterViewInit {

	@ViewChild('physicalAddress', { static: false }) physicalAddress: AddressComponent;
	@ViewChild('mailingAddress', { static: false }) mailingAddress: AddressComponent;

	@Input() reviewPage = false;
	@Output() save = new EventEmitter();
	@Output() patchBusinessData = new EventEmitter();

	businessCategory: Array<BusinessCategory>;
	businessPhoneType: Array<BusinessPhoneType>;
	businessTypes: Array<BusinessType>;
	businessSubTypes: Array<BusinessSubType>;
	ownershipStructure: Array<OwnershipStructure>;
	// selectedSubType: string;
	ownershipStructureData: string;
	ownershippercentage: FormArray;
	sameMailingAddress = true;

	// percentList: any[] = [];
	businessForm: FormGroup;
	businessData: any;
	// edit: any;
	interval: any;
	address: Array<any>;

	editableSection = '';
	editBusinessDetails: boolean;
	editPhysicalAddress: boolean;
	editMailingAddress: boolean;
	editOwnershipPercent: boolean;
	editContactInfo: boolean;
	validationError: boolean;

	// ownershipSum: any;
	businessSubCategoryText: string;

	dateMask = CustomValidation.dateMask;
	phoneMask = CustomValidation.phoneMask;
	taxIDMask = CustomValidation.ssnMask;
	percentMask = CustomValidation.percentageMask;
	datePattern = CustomValidation.getPattern('datePattern');
	phonePattern = CustomValidation.getPattern('phoneNumberPattern');
	taxIDPattern = CustomValidation.getPattern('ssnPattern');
	hideBusinessTaxIdType: boolean;
	// minOwnership = 20;
	businessFormationOptions: IMyDpOptions = CustomValidation.businessFormationOptions;
	dateInvalid = false;
	isZipValid = false;

	constructor(
		private dataService: DataService,
		private formUtilityService: FormUtilityService,
		private mdmService: MdmService,
		private businessFormBuilder: FormBuilder,
		private pageLoaderSvc: PageLoaderService,
		private sharedMdm: SharedMdmService,
		private usps: UspsService,
		private cdr: ChangeDetectorRef,
	) { }

	ngOnInit() {
		this._createForm();
		this._getInitialFieldData();
		this._initReview();

		this.dataService.editableSection.subscribe(section => {
			this.editableSection = section;
		});
		this.businessForm.get('taxtype').valueChanges.subscribe((value) => {
			if (value === 'EIN') {
				this.taxIDMask = CustomValidation.tinMask;
				let ein = this.businessForm['controls'].taxid.value;
				this.businessForm['controls'].taxid.reset();
				this.businessForm['controls'].taxid.setValidators(CustomValidation.ein);
				if (ein && ein.length > 0) {
					ein = ein.replace(/-/g, '');
					ein = [ein.slice(0, 2), '-', ein.slice(2, 9)].join('');
					this.businessForm['controls'].taxid.patchValue(ein);
				}
			}
			if (value === 'SSN') {
				this.taxIDMask = CustomValidation.ssnMask;
				let ssn = this.businessForm['controls'].taxid.value;
				this.businessForm['controls'].taxid.reset();
				this.businessForm['controls'].taxid.setValidators(CustomValidation.ssn);
				if (ssn && ssn.length > 0) {
					ssn = ssn.replace(/-/g, '');
					ssn = [ssn.slice(0, 3), '-', ssn.slice(3, 5), '-', ssn.slice(5, 9)].join('');
					this.businessForm['controls'].taxid.patchValue(ssn);
				}
			}
		});

		this.dataService.zipValidityCheck.subscribe(isZipValid => {
			if (isZipValid) {
				this.isZipValid = true;
			} else {
				this.isZipValid = false;
				if (this.interval) {
					clearInterval(this.interval);
					this.interval = '';
				}
			}
		});
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.patchBusinessData.emit(this);
		}, 1000);
	}

	private _createForm() {
		this.businessForm = new FormGroup({
			businessname: new FormControl('', {
				validators: CustomValidation.businessname,
				updateOn: 'blur'
			}),
			taxid: new FormControl('', {
				validators: CustomValidation.ssn,
				updateOn: 'blur'
			}),
			taxtype: new FormControl('', {
				validators: Validators.required,
				updateOn: 'blur'
			}),
			businessformationdate: new FormControl('', {
				validators: Validators.required,
				updateOn: 'blur'
			}),
			businessformationdatePicker: new FormControl(null),
			businessphonenumber: new FormControl('', {
				validators: CustomValidation.Businessprimaryphonenumber,
				updateOn: 'blur'
			}),
			businesswebsite: new FormControl('', {
				validators: CustomValidation.websiteUrl,
				updateOn: 'blur'
			}),
			description: new FormControl('', {
				validators: Validators.required
			}),
			subbusinesscategory: new FormControl('', {
				validators: Validators.required
			}),
			businesscategory: new FormControl('', {
				validators: Validators.required
			}),
			businessEmail: new FormControl('', {
				validators: CustomValidation.businessEmail,
				updateOn: 'blur'
			}),
			extension: new FormControl('', {
				validators: CustomValidation.businessExtension,
				updateOn: 'blur'
			}),
			phoneType: new FormControl('', {
				validators: Validators.required,
				updateOn: 'blur'
			}),
			ownershippercentage: this.businessFormBuilder.array([])
		}, this._ownershipPercentageValidator);
	}

	hideTaxType(ownershipselected: string) {
		if (ownershipselected === '4') {
			this.hideBusinessTaxIdType = false;
		} else if (ownershipselected === '2') {
			this.hideBusinessTaxIdType = true;
			this.toggleTaxIdType('SSN');
		} else {
			this.hideBusinessTaxIdType = true;
			this.toggleTaxIdType('EIN');
		}
	}

	createOwnershipPercentageForm(responsibleDetails: any) {
		const ownerPercentFormArray = this.businessForm.get('ownershippercentage') as FormArray;
		responsibleDetails.forEach((individual) => {
			if (individual.relationship.isbeneficialowner) {
				ownerPercentFormArray.push(this.pushFormControl(individual));
			}
		});
		this.setMinOwnership();
	}

	pushFormControl(individual) {
		return this.businessFormBuilder.group({
			pid: new FormControl(individual.pid),
			name: new FormControl(`${individual.firstname} ${individual.lastname}`),
			applicanttype: new FormControl(individual.applicanttype),
			percentage: new FormControl('', {
				validators: [
					Validators.required
				],
				updateOn: 'blur'
			})
		});
	}

	setMinOwnership() {
		const formArray = this.businessForm.get('ownershippercentage') as FormArray;
		console.log(formArray);
		formArray.getRawValue().forEach((data, index) => {
			const percentControl = formArray.get('' + index)['controls'].percentage;
			percentControl.setValidators(this.minOwnershipValidator);
		});
	}

	private _ownershipPercentageValidator(businessForm: FormGroup) {
		const formArray = businessForm.get('ownershippercentage') as FormArray;
		let individualError = false;
		for (let i = 0; i < formArray.length; i++) {
			const ownerPercent = formArray.get(i + '.' + 'percentage');
			if (ownerPercent.hasError('minownership')) {
				individualError = true;
				return;
			}
		}
		const sum = businessForm.get('ownershippercentage').value.reduce((a, b) => a + parseFloat(b.percentage), 0);
		if (sum === 0) {
			return { 'invalidtotal': true };
		}
		if (sum) {
			if (sum > 100) {
				for (let i = 0; i < formArray.length; i++) {
					const ownerPercent = formArray.get(i + '.' + 'percentage');
					if (!ownerPercent.hasError('minownership')) {
						ownerPercent.setErrors({ 'invalidtotal': true });
					}
				}
				return { 'invalidtotal': true };
			} else {
				for (let i = 0; i < formArray.length; i++) {
					formArray['controls'][i]['controls'].percentage.setErrors(null);
				}
				return null;
			}
		}
	}

	minOwnershipValidator(percentControl: FormControl) {
		if (!percentControl.value) {
			return { required: true };
		}
		return parseInt(percentControl.value, 10) < 25 ? { 'minownership': true } : null;
	}

	private _initReview() {
		if (this.reviewPage) {
			this.editBusinessDetails = false;
			this.editPhysicalAddress = false;
			this.editMailingAddress = false;
			this.editOwnershipPercent = false;
			this.editContactInfo = false;
		} else {
			this.editBusinessDetails = true;
			this.editPhysicalAddress = true;
			this.editMailingAddress = true;
			this.editOwnershipPercent = true;
			this.editContactInfo = true;
		}
	}

	dateValidation(date: IMyInputFieldChanged) {
		const field = this.businessForm['controls']['businessformationdate'];
		if (field && field.value && date.value !== field.value) {
			field.setErrors({ 'invalid': true });
		}
	}

	onDateChanged(date: IMyInputFieldChanged | any) {
		if (date !== null && typeof date === 'object') {
			date = date.formatted;
		}
		const dateValue = new Date(date);
		const datePicker = { date: { year: dateValue.getFullYear(), month: dateValue.getMonth() + 1, day: dateValue.getDate() } };
		const resetdatePicker = { date: { year: 0, month: 0, day: 0 } };
		let resetPicker: boolean;
		const field = this.businessForm['controls']['businessformationdate'];
		this.dateInvalid = this._getDateInvalidity(date);
		if ((date) && (!(dateValue instanceof Date) || isNaN(dateValue.getTime()) || dateValue.getFullYear() < 1901) || this._getDateInvalidity(date)) {
			this.dateInvalid = true;
		} else {
			this.dateInvalid = false;
		}
		this.dateInvalid && field.value ? field.setErrors({ 'invalid': true }) : field.setErrors(null);
		this.businessForm.patchValue({ businessformationdate: date });
		resetPicker = (this.dateInvalid || !date) ? true : false;
		this.businessForm.patchValue({ businessformationdatePicker: resetPicker ? resetdatePicker : datePicker });
	}

	private _getDateInvalidity(date: any): boolean {
		if (date && date.length !== 10) {
			return true;
		}
		const currentDate = new Date().setHours(0, 0, 0, 0);
		const startDate = new Date(date).getTime();
		if (currentDate - startDate >= 0) {
			return false;
		}
		return true;
	}

	resetPhoneNumber() {
		if (this.businessForm.value['businessphonenumber']) {
			let businessPhone = this.businessForm.value['businessphonenumber'];
			businessPhone = [businessPhone.slice(0, 0), '(', businessPhone.slice(0, 3), ') ', businessPhone.slice(3, 6), '-', businessPhone.slice(6, 10)].join('');
			this.businessForm.patchValue({ businessphonenumber: businessPhone });
		}
	}

	saveData(section) {
		if (section) {
			const dataObj = {
				accounttype: 'business',
				form: this,
				section: section
			};
			if (section === 'PhysicalAddress' || section === 'MailingAddress') {
				if (!this.interval) {
					this.interval = setInterval(() => {
						if (this.isZipValid) {
							clearInterval(this.interval);
							this.interval = '';
							this.save.emit(dataObj);
						}
					}, 1000);
				}
			} else {
				this.save.emit(dataObj);
			}
		}
	}

	refreshForm(section) {
		this.toggleSection(section);
		this.dataService.changeSection('');
		this.businessData = null;
	}

	toggleSectionEdit(section: string) {
		switch (this.editableSection) {
			case '':
				this.getOrUpdateBusinessData(section);
				this.toggleSection(section);
				this.dataService.changeSection(section);
				break;
			case section:
				this.getOrUpdateBusinessData(section);
				this.businessForm.markAsPristine();
				this.businessForm.markAsUntouched();
				this.businessData = null;
				this.toggleSection(section);
				this.dataService.changeSection('');
				break;
			default:
				throw new ApplicationError('1001');
		}
		this.cdr.detectChanges();
	}

	toggleSection(section) {
		this['edit' + section] = !this['edit' + section];
	}

	getOrUpdateBusinessData(section) {
		switch (section) {
			case 'PhysicalAddress':
				if (this.businessData) {
					this.physicalAddress.patchData(this.businessData);
				} else {
					this.businessData = this.physicalAddress.addressForm.getRawValue();
				}
				break;
			case 'MailingAddress':
				if (this.businessData) {
					this.mailingAddress.patchData(this.businessData);
				} else {
					this.businessData = this.mailingAddress.addressForm.getRawValue();
				}
				break;
			default:
				if (this.businessData) {
					this.businessForm.patchValue(this.businessData);
				} else {
					this.businessData = this.businessForm.getRawValue();
				}
		}
	}

	getBusinessTypeText(val: string) {
		let title: string = null;
		if (this.businessTypes !== undefined) {
			if (val !== '' && val !== null && val !== undefined) {
				this.businessTypes.forEach((obj) => {
					if (obj.code === val) {
						title = obj.title;
					}
				});
			}
		}
		return title;
	}

	getOwnershipStructureText(val) {
		let value;
		if (this.ownershipStructure) {
			value = this.ownershipStructure.find(obj => {
				return +obj['ownership_id'] === +val;
			});
		}
		if (value) {
			return value['ownership'];
		}
		return '';
	}

	private _getInitialFieldData() {
		this.mdmService.getBusinessCategory().subscribe((data: Array<BusinessCategory>) => {
			this.businessCategory = data.sort((a, b) => a.title.localeCompare(b.title));
		});
		this.mdmService.getBusinessPhoneType().subscribe((data: Array<BusinessPhoneType>) => {
			this.businessPhoneType = data;
		});
	}

	setBusinessType(ownershipselected: string) {
		if (this.sharedMdm.ownershipStructure && this.sharedMdm.ownershipStructure.length > 0) {
			this.ownershipStructure = this.sharedMdm.ownershipStructure;
			this.ownershipStructureData = this.getOwnershipStructureText(ownershipselected);
			// this.businessForm.controls['ownershipstructure'].setValue(ownershipstructure);
		} else {
			this.sharedMdm.getOwnershipStructure().subscribe((data: Array<OwnershipStructure>) => {
				this.ownershipStructure = data;
				this.ownershipStructureData = this.getOwnershipStructureText(ownershipselected);
				// this.businessForm.controls['ownershipstructure'].setValue(ownershipstructure);
			});
		}
	}

	onFocusSsn() {
		if (this.businessForm.getRawValue().taxid) {
			this.businessForm.patchValue({ taxid: '' });
			this.businessForm.controls.taxid.setErrors(null);
		}
	}

	onFocusOutSsn() {
		if (!this.businessForm.getRawValue().taxid) {
			this.businessForm.controls.taxid.setErrors({ 'required': true });
		}
	}

	// togglePhoneType(phoneType: string) {
	// 	if (phoneType) {
	// 		this.businessForm.patchValue({ phonetype: phoneType });
	// 	}
	// }

	toggleTaxIdType(taxType: string) {
		if (taxType) {
			this.businessForm.patchValue({ taxtype: taxType });
		}
	}

	toggleMailingAddress(sameAddress, resetMailingAddress) {
		this.sameMailingAddress = sameAddress;
		if (resetMailingAddress && this.mailingAddress) {
			this.mailingAddress.addressForm.reset();
		}
	}

	checkValidations() {
		this.validationError = false;
		this.validationError = this.formUtilityService.displayValidations(this.businessForm);
		this.validationError = this.formUtilityService.displayValidations(this.physicalAddress.addressForm, this.validationError);
		if (this.mailingAddress) {
			this.validationError = this.formUtilityService.displayValidations(this.mailingAddress.addressForm, this.validationError);
		}
		return this.validationError;
	}

	patchData(data: BusinessDetails) {
		if (data) {
			this.toggleTaxIdType(data.taxtype);
			if (data.businesscategory) {
				this.setBusinessSubCategory(data.businesscategory, data.subbusinesscategory, true);
			}
			this.businessForm.patchValue(data);
			// this.resetPhoneNumber();
			const physicalAddress = this.getPhysicalAddress(data.businessaddress, 'physicaladdress');
			const mailingAddress = this.getPhysicalAddress(data.businessaddress, 'mailingaddress');
			if (physicalAddress) {
				this.physicalAddress.patchData(physicalAddress[0]);
			}
			if (mailingAddress && (!data['mailingsameasphysical'] || this.reviewPage)) {
				this.toggleMailingAddress(false, false);
				setTimeout(() => {
					this.mailingAddress.patchData(mailingAddress[0]);
				}, 10);
			} else {
				this.toggleMailingAddress(true, false);
			}
		}
		if (!this.reviewPage) {
			this.pageLoaderSvc.hide();
		}
	}

	getPhysicalAddress(address, addresstype) {
		if (address) {
			return address.filter(data => {
				if (data.addresstype) {
					return (data.addresstype).toLowerCase() === addresstype.toLowerCase();
				} else {
					return false;
				}
			}).map(data => {
				delete data['addresstype'];
				return data;
			});
		}
	}

	trim(parentControl, childControl = null) {
		let trimValue;
		const patchObj = {};
		if (childControl) {
			trimValue = this.businessForm.controls[parentControl]['controls'][childControl].value ? this.businessForm.controls[parentControl]['controls'][childControl].value.trim() : null;
			patchObj[childControl] = trimValue;
			this.businessForm.controls[parentControl].patchValue(patchObj);
		} else {
			trimValue = this.businessForm.controls[parentControl].value ? this.businessForm.controls[parentControl].value.trim() : null;
			patchObj[parentControl] = trimValue;
			this.businessForm.patchValue(patchObj);
		}
	}

	standardizeAddress(addressType: string) {
		this.dataService.standardizeCheck.subscribe(data => {
			if (!data || !data.hasOwnProperty('businessdetails' + addressType) || data[addressType + addressType] === true) {
				if (this.businessForm['controls'][addressType]['controls'].numberandstreet.valid) {
					const add = this.businessForm['controls'][addressType]['controls'].numberandstreet.value;
					const zip = this.businessForm.controls[addressType]['controls'].zipcode.value;
					if (add !== null && add !== undefined && add !== '' &&
						zip !== null && zip !== undefined && zip !== '') {
						this.usps.standardizeAddress(add, zip).subscribe(address => {
							if (address !== null && address !== undefined && address !== '') {
								this.dataService.updateStandarizeAddressStatus('businessdetails', addressType);
								const patchObj = {};
								patchObj[addressType] = { numberandstreet: address };
								this.businessForm.patchValue(patchObj);
							}
						});
					}
				}
			}
		});
	}

	zipLookUp(el, addressType: string) {
		const zipControl = this.businessForm.controls[addressType]['controls'].zipcode;
		if (!zipControl.invalid) {
			this.usps.zipLookup(el.target.value).subscribe((data: ZipDetails) => {
				if (!data['error']) {
					if (data.state) {
						const patchObj = {
							state: data.state,
							city: data.city
						};
						this.businessForm.controls[addressType].patchValue(patchObj);
						this.standardizeAddress(addressType);
					} else {
						zipControl.setErrors({ 'incorrect': true });
					}
				} else {
					zipControl.setErrors({ 'incorrect': true });
				}
			});
		}
	}

	getbusinessFormDetails() {
		const businessDetails: BusinessDetails = this.businessForm.getRawValue();
		this.address = [];
		if (this.physicalAddress) {
			this.formatAddress(this.physicalAddress.addressForm.getRawValue(), 'physicalAddress');
			if (this.sameMailingAddress) {
				this.formatAddress(this.physicalAddress.addressForm.getRawValue(), 'mailingAddress');
			} else {
				this.formatAddress(this.mailingAddress.addressForm.getRawValue(), 'mailingAddress');
			}
		}
		// businessDetails.ownershipstructure = this.getOwnershipStructureValue(businessDetails.ownershipstructure);
		businessDetails.businessaddress = this.address;
		// businessDetails.businessphonenumber = this.formUtilityService.resetPhoneNumber(businessDetails.businessphonenumber);
		return businessDetails;
	}

	formatAddress(address, type) {
		address['addresstype'] = type;
		this.address.push(address);
	}

	setBusinessSubCategory(id: string, subCategoryId?: string, callBusinessType = false) {
		this.pageLoaderSvc.show(true, false);
		this.businessForm.controls['description'].reset();
		this.businessForm.controls['subbusinesscategory'].reset();
		this.mdmService.getBusinessSubCategory(id).subscribe((data: Array<BusinessType>) => {
			this.businessSubTypes = data.sort((a, b) => a.title.localeCompare(b.title));
			if (callBusinessType) {
				this.setDescription(subCategoryId);
			}
			this.pageLoaderSvc.hide();
		});
	}

	setDescription(id: string) {
		const type = this.businessSubTypes.filter((data) => data.subtypecode === id);
		if (type && type.length > 0) {
			this.businessForm.controls['description'].setValue(type[0].description);
		}
	}

	getBusinessSubCategoryText(val: string) {
		if (this.businessSubTypes !== undefined) {
			if (val !== '' && val !== null && val !== undefined) {
				this.businessSubTypes.forEach((obj) => {
					if (obj.subtypecode === val) {
						this.businessSubCategoryText = obj.title;
					}
				});
			}
		}
		return this.businessSubCategoryText;
	}

	getBusinessCategoryText(val: string) {
		let title: string = null;
		if (this.businessCategory !== undefined) {
			if (val !== '' && val !== null && val !== undefined) {
				this.businessCategory.forEach((obj) => {
					if (obj.code === val) {
						title = obj.title;
					}
				});
			}
		}
		return title;
	}

	formatNumber(index, value) {
		if (value && !Number.isNaN(value)) {
			this.businessForm.controls['ownershippercentage']['controls'][index].patchValue({ percentage: parseFloat(value) });
		}
	}

	checkValidationsOnBack() {
		this.validationError = false;
		this.validationError = this.formUtilityService.displayValidations(this.businessForm);
		this.validationError = this.formUtilityService.displayValidations(this.physicalAddress.addressForm, this.validationError);
		if (this.mailingAddress) {
			this.validationError = this.formUtilityService.displayValidations(this.mailingAddress.addressForm, this.validationError);
		}
		return this.validationError;
	}
}
