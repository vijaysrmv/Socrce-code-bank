/*--------------------------------------------------------------------------------------------------------
                NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group                  :        PES
Project/Product        :        Newgen - OAO
Application            :        Newgen Portal
Module                 :        Core
File Name              :        modal-focus.directive.spec.ts
Author                 :        Aditya Agrawal
Date (DD/MM/YYYY)      :        10/05/2019
Description            :        Test file for modal-focus.directive.ts
-------------------------------------------------------------------------------------------------------
                CHANGE HISTORY
-------------------------------------------------------------------------------------------------------
Problem No/CR No     Change Date     Changed By        Change Description
--------------------------------------------------------------------------------------------------------*/

import { ModalFocusDirective } from './modal-focus.directive';

describe('ModalFocusDirective', () => {
	it('should create an instance', () => {
		// const directive = new ModalFocusDirective();
		// expect(directive).toBeTruthy();
	});
});
