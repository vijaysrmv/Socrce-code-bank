import { FormatAmountDirective } from './format-amount.directive';

// describe('FormatAmountDirective', () => {
// 	it('should create an instance', () => {
// 		const directive = new FormatAmountDirective();
// 		expect(directive).toBeTruthy();
// 	});
// });
