/*--------------------------------------------------------------------------------------------------------
                NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group                  :        PES
Project/Product        :        Newgen - OAO
Application            :        Newgen Portal
Module                 :
File Name              :
Author                 :
Date (DD/MM/YYYY)      :
Description            :
-------------------------------------------------------------------------------------------------------
                CHANGE HISTORY
-------------------------------------------------------------------------------------------------------
Problem No/CR No     Change Date     Changed By        Change Description
--------------------------------------------------------------------------------------------------------*/

import { Services } from '../../../core/models/product.model';

// export const respServices = <Services> {
// 	ach: true,
// 	atmcard: true,
// 	billpay: true,
// 	debitcard: true,
// 	estatements: true,
// 	oktopay: true,
// 	olb: true,
// 	onlinewire: true
//   };
