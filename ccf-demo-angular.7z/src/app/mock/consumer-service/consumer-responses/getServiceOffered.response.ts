/*--------------------------------------------------------------------------------------------------------
                NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group                  :        PES
Project/Product        :        Newgen - OAO
Application            :        Newgen Portal
Module                 :
File Name              :
Author                 :
Date (DD/MM/YYYY)      :
Description            :
-------------------------------------------------------------------------------------------------------
                CHANGE HISTORY
-------------------------------------------------------------------------------------------------------
Problem No/CR No     Change Date     Changed By        Change Description
--------------------------------------------------------------------------------------------------------*/

import { Product } from '../../../core/models/product.model';

// export const respServicesOffered = <Array<Product>>
// [
// 	{
// 		'productid': '056',
// 		'accounttypeid': 'DD',
// 		'accounttypedescription': 'demanddraft',
// 		'atmcard': false,
// 		'debitcard': true,
// 		'oktopay': true,
// 		'olb': true,
// 		'billpay': true,
// 		'estatements': true,
// 		'isbusinesscustomer': false,
// 		'interestrate': 2.35,
// 		'ach': false,
// 		'status': false,
// 		'minimumamount': 25,
// 		'productname': 'FreeChecking',
// 		'onlinewire': false
// 	},
// 	{
// 		'productid': '060',
// 		'accounttypeid': 'DD',
// 		'accounttypedescription': 'demanddraft',
// 		'atmcard': false,
// 		'debitcard': true,
// 		'oktopay': true,
// 		'olb': true,
// 		'billpay': true,
// 		'estatements': true,
// 		'isbusinesscustomer': false,
// 		'interestrate': 3.2,
// 		'ach': false,
// 		'status': false,
// 		'minimumamount': 25,
// 		'productname': 'AdvantageChecking',
// 		'onlinewire': false
// 	},
// 	{
// 		'productid': '272',
// 		'sharetype': 'DD',
// 		'accounttypedescription': 'demanddraft',
// 		'atmcard': false,
// 		'debitcard': true,
// 		'oktopay': true,
// 		'olb': true,
// 		'billpay': true,
// 		'estatements': true,
// 		'isbusinesscustomer': false,
// 		'interestrate': 3.5,
// 		'ach': false,
// 		'status': true,
// 		'minopeningdeposit': 25,
// 		'productname': 'RocklandCompleteChecking',
// 		'onlinewire': false
// 	}
// ];
